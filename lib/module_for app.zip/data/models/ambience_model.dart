class Ambience {
  final String title;
  final String tag;
  final int duration;
  final String audio;

  Ambience({
    required this.title,
    required this.tag,
    required this.duration,
    required this.audio,
  });

  factory Ambience.fromJson(Map<String, dynamic> json) {
    return Ambience(
      title: json['title'],
      tag: json['tag'],
      duration: json['duration'],
      audio: json['audio'],
    );
  }
}