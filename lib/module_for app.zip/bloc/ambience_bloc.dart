import 'package:arvya_ambience_app/data/models/ambience_model.dart';
import 'package:arvya_ambience_app/data/repository/journel_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

abstract class AmbienceEvent {}

class LoadAmbiences extends AmbienceEvent {}

class AmbienceState {
  final List<Ambience> ambiences;

  AmbienceState({required this.ambiences});
}


class AmbienceBloc extends Bloc<AmbienceEvent, AmbienceState> {
  final AmbienceRepository repository;

  AmbienceBloc(this.repository) : super(AmbienceState(ambiences: [])) {
    on<LoadAmbiences>((event, emit) async {
      final data = await repository.loadAmbiences();

      emit(AmbienceState(ambiences: data));
    });
  }
}