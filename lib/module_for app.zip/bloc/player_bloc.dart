import 'package:flutter_bloc/flutter_bloc.dart';
import '../data/models/ambience_model.dart';

class PlayerState {
  final bool isPlaying;
  final Ambience? ambience;

  PlayerState({this.isPlaying = false, this.ambience});
}

abstract class PlayerEvent {}

class StartSession extends PlayerEvent {
  final Ambience ambience;

  StartSession(this.ambience);
}

class StopSession extends PlayerEvent {}

class PlayerBloc extends Bloc<PlayerEvent, PlayerState> {
  PlayerBloc() : super(PlayerState()) {

    on<StartSession>((event, emit) {
      emit(PlayerState(
        isPlaying: true,
        ambience: event.ambience,
      ));
    });

    on<StopSession>((event, emit) {
      emit(PlayerState(
        isPlaying: false,
        ambience: null,
      ));
    });

  }
}