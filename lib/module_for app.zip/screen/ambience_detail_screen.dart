import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/player_bloc.dart';
import '../data/models/ambience_model.dart';
import 'session_player_screen.dart';

class AmbienceDetailScreen extends StatelessWidget {
  final Ambience ambience;

  const AmbienceDetailScreen({super.key, required this.ambience});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(ambience.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Text(
              ambience.title,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),

            Text("Tag: ${ambience.tag}"),

            const SizedBox(height: 10),

            Text("Duration: ${ambience.duration} seconds"),

            const SizedBox(height: 30),

            ElevatedButton(
              child: const Text("Start Session"),
              onPressed: () {

                context.read<PlayerBloc>().add(
                  StartSession(ambience),
                );

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SessionPlayerScreen(ambience: ambience),
                  ),
                );
              },
            )
          ],
        ),
      ),
    );
  }
}