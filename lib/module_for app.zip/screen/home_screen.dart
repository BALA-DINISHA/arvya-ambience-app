import 'package:arvya_ambience_app/screen/ambience_detail_screen.dart';
import 'package:arvya_ambience_app/screen/journel_history_screen.dart';
import 'package:arvya_ambience_app/widgets/mini_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/ambience_bloc.dart';
import '../data/models/ambience_model.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ambiences"),
        actions: [
          IconButton(
            icon: const Icon(Icons.book),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => JournalHistoryScreen(),
                ),
              );
            },
          )
        ],
      ),
      body: BlocBuilder<AmbienceBloc, AmbienceState>(
        builder: (context, state) {
          if (state.ambiences.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          return  Column(
            children: [

              Expanded(
                child: BlocBuilder<AmbienceBloc, AmbienceState>(
                  builder: (context, state) {
                    return ListView.builder(
                      itemCount: state.ambiences.length,
                      itemBuilder: (context, index) {

                        final ambience = state.ambiences[index];

                        return ListTile(
                          title: Text(ambience.title),
                          subtitle: Text(ambience.tag),
                        );
                      },
                    );
                  },
                ),
              ),

              const MiniPlayer(),

            ],
          );
        },
      ),
    );
  }
}