import 'package:arvya_ambience_app/screen/journel_history_screen.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class ReflectionScreen extends StatefulWidget {

  final String ambienceTitle;

  const ReflectionScreen({super.key, required this.ambienceTitle});

  @override
  State<ReflectionScreen> createState() => _ReflectionScreenState();
}

class _ReflectionScreenState extends State<ReflectionScreen> {

  final TextEditingController controller = TextEditingController();
  String mood = "Calm";

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: const Text("Reflection")),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [

            const Text(
              "What is gently present with you right now?",
              style: TextStyle(fontSize: 20),
            ),

            const SizedBox(height: 20),

            TextField(
              controller: controller,
              maxLines: 4,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Write your thoughts...",
              ),
            ),

            const SizedBox(height: 20),

            DropdownButton<String>(
              value: mood,
              items: ["Calm","Grounded","Energized","Sleepy"]
                  .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  mood = value!;
                });
              },
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {

                var box = Hive.box('journalBox');

                box.add({
                  "ambience": widget.ambienceTitle,
                  "text": controller.text,
                  "mood": mood,
                  "date": DateTime.now().toString(),
                });

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => JournalHistoryScreen(),
                  ),
                );

              },
              child: const Text("Save Reflection"),
            )
          ],
        ),
      ),
    );
  }
}