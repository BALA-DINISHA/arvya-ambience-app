import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class JournalHistoryScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    var box = Hive.box('journalBox');
    var entries = box.values.toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Journal History")),

      body: entries.isEmpty
          ? const Center(
        child: Text("No reflections yet. Start a session to begin."),
      )
          : ListView.builder(
        itemCount: entries.length,
        itemBuilder: (context, index) {

          var entry = entries[index];

          return ListTile(
            title: Text(entry["ambience"]),
            subtitle: Text(entry["mood"]),
            trailing: Text(entry["date"]),
          );
        },
      ),
    );
  }
}