import 'dart:async';

import 'package:arvya_ambience_app/bloc/player_bloc.dart';
import 'package:arvya_ambience_app/screen/reflection_screen.dart';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../data/models/ambience_model.dart';

class SessionPlayerScreen extends StatefulWidget {
  final Ambience ambience;

  const SessionPlayerScreen({super.key, required this.ambience});

  @override
  State<SessionPlayerScreen> createState() => _SessionPlayerScreenState();
}

class _SessionPlayerScreenState extends State<SessionPlayerScreen> {
  int elapsedSeconds = 0;
  Timer? sessionTimer;
  final AudioPlayer player = AudioPlayer();
  bool isPlaying = false;
  void startTimer() {
    sessionTimer = Timer.periodic(
      const Duration(seconds: 1),
          (timer) {

        if (!mounted) return;

        setState(() {
          elapsedSeconds++;
        });

        if (elapsedSeconds >= widget.ambience.duration) {
          endSession();
        }

      },
    );
  }
  @override
  void initState() {
    super.initState();
    startAudio();
    startTimer();
  }

  void startAudio() async {
    await player.setReleaseMode(ReleaseMode.loop);

    await player.play(
      AssetSource('audio/${widget.ambience.audio}'),
    );

    setState(() {
      isPlaying = true;
    });
  }

  void pauseAudio() async {
    await player.pause();

    setState(() {
      isPlaying = false;
    });
  }

  void resumeAudio() async {
    await player.resume();

    setState(() {
      isPlaying = true;
    });
  }
  void endSession() {

    context.read<PlayerBloc>().add(StopSession());

    player.stop();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReflectionScreen(
          ambienceTitle: widget.ambience.title,
        ),
      ),
    );
  }

  @override

  void dispose() {
    sessionTimer?.cancel();
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.ambience.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "$elapsedSeconds / ${widget.ambience.duration} seconds",
              style: const TextStyle(fontSize: 20),
            ),
            Text(
              widget.ambience.title,
              style: const TextStyle(fontSize: 28),
            ),

            const SizedBox(height: 40),

            IconButton(
              iconSize: 80,
              icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
              onPressed: () {
                if (isPlaying) {
                  pauseAudio();
                } else {
                  resumeAudio();
                }
              },
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: endSession,
              child: const Text("End Session"),
            )
          ],
        ),
      ),
    );
  }
}