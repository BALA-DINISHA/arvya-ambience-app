import 'package:arvya_ambience_app/bloc/ambience_bloc.dart';
import 'package:arvya_ambience_app/bloc/player_bloc.dart';
import 'package:arvya_ambience_app/data/repository/journel_repository.dart';
import 'package:arvya_ambience_app/screen/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  await Hive.openBox('journalBox');
  final ambienceRepository = AmbienceRepository();

  runApp(MyApp(ambienceRepository));
}

class MyApp extends StatelessWidget {
  final AmbienceRepository ambienceRepository;

  const MyApp(this.ambienceRepository, {super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
          AmbienceBloc(ambienceRepository)..add(LoadAmbiences()),
        ),
        BlocProvider(
          create: (context) => PlayerBloc(),
        ),
      ],
      child: MaterialApp(
        home: HomeScreen(),
      ),
    );
  }
}