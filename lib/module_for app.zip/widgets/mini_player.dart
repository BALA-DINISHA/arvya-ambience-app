import 'package:arvya_ambience_app/screen/session_player_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/player_bloc.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {

    return BlocBuilder<PlayerBloc, PlayerState>(
      builder: (context, state) {

        if (!state.isPlaying || state.ambience == null) {
          return const SizedBox();
        }

        return Container(
          height: 70,
          color: Colors.black12,

          child: ListTile(
            title: Text(state.ambience!.title),

            trailing: const Icon(Icons.pause),

            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      SessionPlayerScreen(ambience: state.ambience!),
                ),
              );
            },
          ),
        );
      },
    );
  }
}